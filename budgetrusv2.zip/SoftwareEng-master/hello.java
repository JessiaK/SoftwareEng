/*
This is a simple program that outputs the name of the user 
that runs the program. 
*/
import java.util.Scanner;
public class Hello {

	public static void main(String[] args){
		
		Scanner x = new Scanner.(system.in);  //scanner being declared and initialized
		String name = x.nextLine()  //name would be the input from user
		System.out.println(name + "is the user that is running this program."); //getting the name printed
		
	}
}
